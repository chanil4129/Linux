#include <stdio.h>
int main(void){
}
