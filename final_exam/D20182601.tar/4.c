#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <signal.h>

int main(void){
	sigset_t sig_set;
	int count;

	sigemptyset(&sig_set);
	sigaddset(&sig_set,SIGINT);
	sigprocmask(SIG_BLOCK,&sig_set,NULL);

	for(count=3;count>0;count--){
		printf("count %d\n",count);
		sleep(1);
	}

	printf("Unblocking Ctrl-C\n");
	sigprocmask(SIG_UNBLOCK,&sig_set,NULL);
	printf("If you type Ctrl-C during count, this sentence is not output.\n");
	while(1);
	exit(0);
}
