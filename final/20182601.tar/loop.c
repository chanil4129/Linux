#include <stdio.h>

int main(void){
	while(1){
		
	}
	printf("not loop\n");
}
